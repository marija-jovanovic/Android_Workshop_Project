package com.example.novproekt;
import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
        import android.os.Bundle;
        import android.widget.Toast;
        import com.google.android.gms.maps.CameraUpdateFactory;
        import com.google.android.gms.maps.SupportMapFragment;
        import com.google.android.gms.location.FusedLocationProviderClient;
        import com.google.android.gms.location.LocationServices;
        import com.google.android.gms.maps.GoogleMap;
        import com.google.android.gms.maps.OnMapReadyCallback;
        import com.google.android.gms.maps.model.LatLng;
        import com.google.android.gms.maps.model.MarkerOptions;
        import com.google.android.gms.tasks.OnSuccessListener;
        import com.google.android.gms.tasks.Task;
        import androidx.annotation.NonNull;
        import androidx.core.app.ActivityCompat;
        import androidx.fragment.app.FragmentActivity;
import java.lang.Thread;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class StudentPresenceActivity extends FragmentActivity implements OnMapReadyCallback {

    public String korisnik;
    public String cas_id;
    Location currentLocation;

    int flag = 0;

    private SQLiteDatabase db;

    private String vreme;

    private String today;

    private Calendar calendar = Calendar.getInstance();
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_presence);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");
        cas_id = intent.getExtras().getString("casId");

        db = openOrCreateDatabase("workshop",MODE_PRIVATE,null);

      //  db.execSQL("DROP TABLE IF EXISTS '" + "prisutni" + "'");

        String CREATE_TABLE_PRISUTNI = "CREATE TABLE IF NOT EXISTS prisutni" + " ("
                + "STUDENT_ID VARCHAR," + "CAS_ID VARCHAR," + "DATUM VARCHAR" + ")";
        db.execSQL(CREATE_TABLE_PRISUTNI);

         //predmetite sto gi ima zapisano
        Cursor c = db.rawQuery("SELECT * FROM termini WHERE CAS_ID = '" + cas_id + "'", null);

            if(c.moveToFirst()) {
                vreme = c.getString(4);
            }
            c.close();


        Toast.makeText(this, korisnik + " " + cas_id, Toast.LENGTH_SHORT).show();

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fetchLocation();
    }
    private void fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentLocation = location;
                    Toast.makeText(getApplicationContext(), currentLocation.getLatitude() + "" + currentLocation.getLongitude(), Toast.LENGTH_SHORT).show();
                    if(currentLocation.getLatitude() == 42.0049817 && currentLocation.getLongitude() == 21.4083117){
                        ContentValues insertValues = new ContentValues();
                        insertValues.put("STUDENT_ID", korisnik);
                        insertValues.put("CAS_ID",cas_id);
                        Date date = Calendar.getInstance().getTime();
                        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                        today = formatter.format(date);
                        insertValues.put("DATUM", today);
                        Cursor c1 = db.rawQuery("SELECT * FROM prisutni WHERE DATUM = '" + today + "'", null);
                        if(c1.moveToFirst()){
                            if(c1.getString(0).equals(korisnik) && c1.getString(1).equals(cas_id)) {
                                Toast.makeText(getApplicationContext(), "You have already confirmed your presence.", Toast.LENGTH_SHORT).show();
                                flag = 1;
                            }
                                while(c1.moveToNext()){
                                    if(c1.getString(0).equals(korisnik) && c1.getString(1).equals(cas_id)) {
                                        Toast.makeText(getApplicationContext(), "You have already confirmed your presence.", Toast.LENGTH_SHORT).show();
                                        flag = 1;
                                    }
                                }
                                c1.close();
                            }

                        if(flag == 0){
                        db.insert("prisutni", null, insertValues);
                        Toast.makeText(getApplicationContext(), "You have successfully confirmed your presence.", Toast.LENGTH_SHORT).show(); }

                        if(flag == 1){
                            String [] oddelno = vreme.split(":");
                           // calendar.set(Calendar.HOUR_OF_DAY, 17);
                            //calendar.set(Calendar.MINUTE, 35);
                            if((Integer.parseInt(oddelno[0]) == calendar.get(Calendar.HOUR_OF_DAY))
                                    && (Integer.parseInt(oddelno[1]) == calendar.get(Calendar.MINUTE))){
                                Intent i = new Intent(StudentPresenceActivity.this, AnketaActivity.class);
                                i.putExtra("cas_id", cas_id);
                                i.putExtra("datum", today);
                                startActivity(i);
                                finish();
                            }
                        }


                    }
                    else{
                        Toast.makeText(getApplicationContext(), "Sorry, you cannot confirm your presence due to inadequate location.", Toast.LENGTH_SHORT).show();
                    }
                    SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.myMap);
                    assert supportMapFragment != null;
                    supportMapFragment.getMapAsync(StudentPresenceActivity.this);
                }
            }
        });
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng latLng = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("I am here!");
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 5));
        googleMap.addMarker(markerOptions);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    fetchLocation();
                }
                break;
        }
    }
}