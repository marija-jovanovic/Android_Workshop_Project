package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EnrollCourseActivity extends AppCompatActivity {

    String korisnik;
    String selektiran;
    private SQLiteDatabase db;

    public static final String NOTIFICATION_CHANNEL_ID = "10001";
    private final static String default_notification_channel_id = "default";

    final Calendar myCalendar = Calendar.getInstance();
    int b = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enroll_course);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");
        db = openOrCreateDatabase("workshop", MODE_PRIVATE, null);



       List<String> values = new ArrayList<String>();
        values.add("Choose your course");
        //List<Integer> ids = new ArrayList<Integer>();
        //List<String> finalen = new ArrayList<String>();
        Cursor c = db.rawQuery("SELECT * FROM register_course", null);
        if (c != null) {
            if (c.moveToFirst()) {
                values.add(c.getString(0));
                //ids.add(c.getInt(0));
                // finalen.add(String.valueOf(c.getInt(0)) + "." + c.getString(1));
            }
            while (c.moveToNext()) {
                values.add(c.getString(0));
                //ids.add(c.getInt(0));
                //  finalen.add(String.valueOf(c.getInt(0)) + "." + c.getString(1));
            }
            c.close();
        }

      // db.execSQL("DROP TABLE IF EXISTS zapisan");
        String CREATE_TABLE_ENROLLED = "CREATE TABLE IF NOT EXISTS zapisan" + " ("
                + "PREDMET VARCHAR," + "STUDENT_ID VARCHAR," + "PRIMARY KEY (PREDMET, STUDENT_ID) " + ")";
        db.execSQL(CREATE_TABLE_ENROLLED);

        List<String> moi = new ArrayList<String>(); //predmetite sto drugite profesori gi imaat zapisano
        Cursor c2 = db.rawQuery("SELECT * FROM zapisan WHERE STUDENT_ID = '" + korisnik + "'", null);
        if (c2 != null) {
            if (c2.moveToFirst()) {
                moi.add(c2.getString(0));
            }
            while (c2.moveToNext()) {
                moi.add(c2.getString(0));
            }
            c2.close();
        }

        if (!moi.isEmpty()) {
            for (int i = 0; i < moi.size(); i++) {
                for (int j = 0; j < values.size(); j++) {
                    if (moi.get(i).equals(values.get(j)))
                        values.remove(j);
                }
            }
        }


        Spinner spin = (Spinner) findViewById(R.id.coursesspinner);
        spin.setAdapter(
                new ArrayAdapter(
                        this,
                        android.R.layout.simple_list_item_1,
                        values));

        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> spin, View v, int i, long id) {

                selektiran = spin.getSelectedItem().toString();
                if (!selektiran.equals("Choose your course")) {
                    ContentValues insertValues = new ContentValues();
                    insertValues.put("PREDMET", selektiran);
                    insertValues.put("STUDENT_ID", korisnik);
                    db.insert("zapisan", null, insertValues);
                    Toast.makeText(EnrollCourseActivity.this, "Successfully enrolled.", Toast.LENGTH_SHORT).show();



                    finish();

                }


                //finish();
            }


            // TextView result = (TextView) findViewById(R.id.turtle_result);

            public void onNothingSelected(AdapterView<?> parent) {
            } // empty
        });

        // String[] podelen = selected.split(".");


    }



    public void back(View view) {
        finish();
    }


}

