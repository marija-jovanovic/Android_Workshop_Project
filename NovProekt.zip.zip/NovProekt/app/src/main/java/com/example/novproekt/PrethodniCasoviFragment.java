package com.example.novproekt;

import static android.content.Context.MODE_PRIVATE;

import android.content.ContentValues;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class PrethodniCasoviFragment extends Fragment {

    private static final int REQUEST_CODE_DETAILS_ACTIVITY = 1234;
    private SQLiteDatabase db;

    prethodniAdapter pAdapter;

    RecyclerView mRecyclerView;

    String korisnik;

    public PrethodniCasoviFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_prethodni_casovi, container, false);
        return view;

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        PrethodniActivity xxx = (PrethodniActivity) getActivity();
        korisnik = xxx.korisnik;

        db = getActivity().openOrCreateDatabase("workshop", MODE_PRIVATE, null);

        mRecyclerView = (RecyclerView)
                getActivity().findViewById(R.id.list);
// оваа карактеристика може да се користи ако се знае дека промените
// во содржината нема да ја сменат layout големината на RecyclerView
        mRecyclerView.setHasFixedSize(true);
// ќе користиме LinearLayoutManager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
// и default animator (без анимации)
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());


        List<String> predmeti = new ArrayList<String>();
        Cursor c2 = db.rawQuery("SELECT * FROM register_course WHERE PROF_ID = '" + korisnik + "'", null);
        if(c2 != null){
            if(c2.moveToFirst()){
                predmeti.add(c2.getString(0));
            }
            while(c2.moveToNext()){
            predmeti.add(c2.getString(0));
            }
        }
        c2.close();

        List<String> l = new ArrayList<String>();
        List<String> ajdi = new ArrayList<String>();
        ajdi.add("Pick a class");
        Cursor c3 = db.rawQuery("SELECT * FROM termini", null);
        if(c3 != null){
            if(c3.moveToFirst()){
                for(int i = 0; i < predmeti.size(); i++) {
                    if (c3.getString(1).equals(predmeti.get(i))){
                        ajdi.add(c3.getString(0) + " " + c3.getString(1) +
                                " " + c3.getString(2) + " " + c3.getString(3) + " " + c3.getString(4));
                        break;
                    }
                }
            }
            while(c3.moveToNext()){
                for(int i = 0; i < predmeti.size(); i++) {
                    if (c3.getString(1).equals(predmeti.get(i))){
                        ajdi.add(c3.getString(0) + " " + c3.getString(1) +
                                " " + c3.getString(2) + " " + c3.getString(3) + " " + c3.getString(4));
                        break;
                    }
                }
            }
        }
        c3.close();



        Spinner spin = (Spinner) getActivity().findViewById(R.id.casovispinner);
        spin.setAdapter(
                new ArrayAdapter(
                        getActivity(),
                        android.R.layout.simple_list_item_1,
                        ajdi));

        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                           public void onItemSelected(AdapterView<?> spin, View v, int i, long id) {

                                               String selektiran = spin.getSelectedItem().toString();
                                               if (!selektiran.equals("Pick a class")) {
                                                    String[] niza = selektiran.split(" ");
                                                   List<String> studenti = new ArrayList<String>();
                                                   Cursor c1 = db.rawQuery("SELECT * FROM prisutni WHERE CAS_ID = '" + niza[0] + "'", null);
                                                   if (c1 != null) {
                                                       if (c1.moveToFirst()) {
                                                           studenti.add(c1.getString(0) + "\n" + c1.getString(1) + "\n" + c1.getString(2));
                                                       }
                                                       while (c1.moveToNext()) {
                                                           studenti.add(c1.getString(0) + "\n" + c1.getString(1) + "\n" + c1.getString(2));
                                                       }
                                                   }
                                                   c1.close();


                                                   pAdapter = new prethodniAdapter(studenti, R.layout.my_rowp, getActivity());
//прикачување на адаптерот на RecyclerView
                                                   mRecyclerView.setAdapter(pAdapter);

                                                   if (getResources().getConfiguration().orientation ==
                                                           Configuration.ORIENTATION_LANDSCAPE) {
                                                       // show in same activity
                                                       PrethodniAnketiFragment frag = (PrethodniAnketiFragment) getFragmentManager().findFragmentById(R.id.anketi);
                                                       frag.setCasid(niza[0]);
                                                   }

                                               }

                                           }


            public void onNothingSelected(AdapterView<?> parent) {
            } // empty
        });

    }

    /*
     * Дава повеќе детали за избраниот град
     * Во portrait режим отвора втора активност
     * Во landscape режим го ажуира DetailsFragment во рамките на истата активност
     */
  /*  public void showDetailsAboutCity() {
        RadioGroup group = (RadioGroup) getActivity().findViewById(R.id.cities);
        int id = group.getCheckedRadioButtonId();

        if (getResources().getConfiguration().orientation ==
                Configuration.ORIENTATION_LANDSCAPE) {
            // show in same activity
            DetailsFragment frag = (DetailsFragment) getFragmentManager().findFragmentById(R.id.fragment2);
            frag.setCityId(id);
        } else {
            // стартување детали како сопствена активност
            Intent intent = new Intent(getActivity(), DetailsActivity.class);
            intent.putExtra("city_id", id);
            startActivityForResult(intent, REQUEST_CODE_DETAILS_ACTIVITY);
        }
    }

    /*
     * Ажурира која слика на град се прикажува според тоа кој radio button е кликнат
     */
  /*  private void updateCityImage() {
        ImageButton img = (ImageButton) getActivity().findViewById(R.id.city);
        RadioGroup group = (RadioGroup) getActivity().findViewById(R.id.cities);
        int checkedID = group.getCheckedRadioButtonId();
        if (checkedID == R.id.paris) {
            img.setImageResource(R.drawable.paris);
        } else if (checkedID == R.id.london) {
            img.setImageResource(R.drawable.london);
        } else if (checkedID == R.id.berlin) {
            img.setImageResource(R.drawable.berlin);
        } else if (checkedID == R.id.rome) {
            img.setImageResource(R.drawable.rome);
        }

        if (getResources().getConfiguration().orientation ==
                Configuration.ORIENTATION_LANDSCAPE) {
            showDetailsAboutCity();
        }
    } */
}
