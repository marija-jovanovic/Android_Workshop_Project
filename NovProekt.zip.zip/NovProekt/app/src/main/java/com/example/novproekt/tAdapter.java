package com.example.novproekt;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class tAdapter extends RecyclerView.Adapter<tAdapter.ViewHolder> {
    private List<String> myList;
    private int rowLayout;
    private Context mContext;

    private Context context;
    public String korisnik;
    // Референца на views за секој податок
// Комплексни податоци може да бараат повеќе views per item
// Пристап до сите views за податок се дефинира во view holder
    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView myName;
        public ViewHolder(View itemView) {
            super(itemView);
            myName = (TextView) itemView.findViewById(R.id.Name);
        }
    }
    // конструктор
    public tAdapter(List<String> myList, int rowLayout, Context context) {
        this.myList = myList;
        this.rowLayout = rowLayout;
        this.mContext = context;
    }
    // Креирање нови views (повикано од layout manager)
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(rowLayout, viewGroup, false);
        return new ViewHolder(v);
    }

    // Замена на содржината во view (повикано од layout manager)
    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        String entry = myList.get(i);
        viewHolder.myName.setText(entry);

        viewHolder.myName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context = viewHolder.myName.getContext();
                TextView tv = (TextView) v;
                String niza [] = (String.valueOf(tv.getText())).split("\n");
                if(niza.length == 7){ //stanuva zbor za profesor
                    Intent i = new Intent(context, PrisutniStudentiZaProfActivity.class);
                    i.putExtra("id", niza[5]);
                    i.putExtra("casId", niza[0]);
                    Date date = Calendar.getInstance().getTime();
                    DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                   String today = formatter.format(date);
                   i.putExtra("datum", today);
                    context.startActivity(i);
                }
               // Toast.makeText(mContext, tv.getText(), Toast.LENGTH_SHORT).show();
                else{
                Intent i = new Intent(context, StudentPresenceActivity.class);
                i.putExtra("id", niza[5]);
                i.putExtra("casId", niza[0]);
                context.startActivity(i); }
            }
        });
    }
    // Пресметка на големината на податочното множество (повикано од
   // layout manager)
    @Override
    public int getItemCount() {
        return myList == null ? 0 : myList.size();
    }
}
