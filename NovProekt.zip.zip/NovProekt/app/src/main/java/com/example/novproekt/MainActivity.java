package com.example.novproekt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    Button kursevi;

    Button termini;

    String uloga;
    String korisnik;
    private SQLiteDatabase db;
    //private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");
        kursevi = (Button)findViewById(R.id.register_course);

        TextView tekst;
        tekst = (TextView)findViewById(R.id.pozdrav);
        tekst.setText("Hello, " + korisnik);

        db = openOrCreateDatabase("workshop",MODE_PRIVATE,null);
        String CREATE_TABLE_PROFESOR = "CREATE TABLE IF NOT EXISTS professor" + " ("
                +"ID VARCHAR PRIMARY KEY " + ")";
        db.execSQL(CREATE_TABLE_PROFESOR);

        ContentValues insertValues = new ContentValues();
        insertValues.put("ID", korisnik);
        db.insert("professor", null, insertValues);

        //db.execSQL("DROP TABLE IF EXISTS '" + "student" + "'");

    }


    public void register(View view) {
        Intent i = new Intent(MainActivity.this, RegisterCourseActivity.class);
        i.putExtra("id", korisnik);
        startActivity(i);
    }

    public void termin(View view) {
        Intent i = new Intent(MainActivity.this, TerminActivity.class);
        i.putExtra("id", korisnik);
        startActivity(i);
    }

    public void raspored(View view) {
        Intent i = new Intent(MainActivity.this, ProfScheduleActivity.class);
        i.putExtra("id", korisnik);
        startActivity(i);
    }

    public void vidiTekovni(View view) {
        Intent i = new Intent(MainActivity.this, PresentStudentProfActivity.class);
        i.putExtra("id", korisnik);
        startActivity(i);
    }

    public void vidiPrethodni(View view) {
        Intent i = new Intent(MainActivity.this, PrethodniActivity.class);
        i.putExtra("id", korisnik);
        startActivity(i);
    }
}