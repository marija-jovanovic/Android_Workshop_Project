package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;

public class PrethodniActivity extends AppCompatActivity {

    public String korisnik;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prethodni);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");


    }

}
