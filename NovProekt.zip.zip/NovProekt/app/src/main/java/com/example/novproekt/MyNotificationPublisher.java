package com.example.novproekt;

import static android.content.Intent.getIntent;
import static android.content.Intent.getIntentOld;
import static com.example.novproekt.EnrollCourseActivity.NOTIFICATION_CHANNEL_ID;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;


public class MyNotificationPublisher extends BroadcastReceiver {
    public static String NOTIFICATION_ID = "notification-id";
    public static String NOTIFICATION = "notification";

    private static final String CHANNEL_ID = "this.is.my.channelId";

    int id = 0;
    String naslov = "";

    @Override
    public void onReceive(Context context, Intent intent) {
/*
        NotificationManager notificationManager = (NotificationManager)context.getSystemService(NotificationManager.class);

        Notification notification = intent.getParcelableExtra(NOTIFICATION);
        id = intent.getIntExtra(NOTIFICATION_ID, 0);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelName = "My Background Service";
            String desc = "Channel for Alarm Manager";
            NotificationChannel chan = new NotificationChannel("com.example.novproekt",
                    channelName, NotificationManager.IMPORTANCE_HIGH);
            chan.setDescription(desc);
           // chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            notificationManager.createNotificationChannel(chan);
        }


        notificationManager.notify(id, notification);

*/

        // Intent nextActivity = new Intent(context, NotificationActivity.class);
        // intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        // PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, nextActivity, 0);
        id = intent.getIntExtra(NOTIFICATION_ID, 0);
        naslov = intent.getStringExtra("Naslov");

        Intent nextActivity = new Intent(context, LoginActivity.class);
        nextActivity.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, id, nextActivity, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "androidknowledge")
                .setSmallIcon(R.drawable.baseline_notifications_24)
                .setContentTitle(naslov)
                .setContentText("Your lesson will start in 2 hours!")
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(pendingIntent);
        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(context);
        if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManagerCompat.notify(id, builder.build());



    }

}

