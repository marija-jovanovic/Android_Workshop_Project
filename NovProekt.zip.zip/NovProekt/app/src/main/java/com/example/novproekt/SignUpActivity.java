package com.example.novproekt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


public class SignUpActivity extends AppCompatActivity {

    // Declare any other necessary variables.
    //private FirebaseAuth auth;
    private EditText signupEmail, signupPassword, getRole;
    private Button signupButton;
    private TextView loginRedirectText;
    private RadioGroup radioGroup;

    private String kopce;
    //private RadioButton kopce;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        db = openOrCreateDatabase("workshop",MODE_PRIVATE,null);
       // db.execSQL("CREATE TABLE IF NOT EXISTS identitet(id VARCHAR, role VARCHAR);");
        String CREATE_TABLE_IDENTITET = "CREATE TABLE IF NOT EXISTS identitet ("+"ID VARCHAR primary key,"
                + "ROLE VARCHAR);";
        db.execSQL(CREATE_TABLE_IDENTITET);

       // db.execSQL("DROP TABLE IF EXISTS '" + "student" + "'");

        //Initialize the FirebaseAuth instance in the onCreate()
       // auth = FirebaseAuth.getInstance();
        signupEmail = findViewById(R.id.signup_email);
        signupPassword = findViewById(R.id.signup_password);
        signupButton = findViewById(R.id.signup_button);
        loginRedirectText = findViewById(R.id.loginRedirectText);
       // getRole = findViewById(R.id.uloga);


        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = signupEmail.getText().toString().trim();
                String pass = signupPassword.getText().toString().trim();

                //db.execSQL("DROP TABLE IF EXISTS '" + "student" + "'");

                if (user.isEmpty()){
                    signupEmail.setError("Email cannot be empty");
                }
                if(pass.isEmpty()){
                    signupPassword.setError("Password cannot be empty");
                }
                if(kopce == null){
                    Toast.makeText(SignUpActivity.this, "You must choose your role.", Toast.LENGTH_SHORT).show();
                }else{

                                Toast.makeText(SignUpActivity.this, "Signup Successful", Toast.LENGTH_SHORT).show();
                              //  Toast.makeText(SignUpActivity.this, getRole.getText().toString(), Toast.LENGTH_SHORT).show();
                                ContentValues insertValues = new ContentValues();
                                insertValues.put("ID", user);
                    insertValues.put("ROLE", kopce);
                                //insertValues.put("ROLE", getRole.getText().toString());
                                db.insert("identitet", null, insertValues);
                    startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                              //  i.putExtra("id", user);
                               // i.putExtra("uloga", kopce);

                                //startActivity(new Intent(SignUpActivity.this, LoginActivity.class));

                }
            }
        });

        loginRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
            }
        });

    }

    @Override
    protected void onPause() {
        super.onPause();
        db.close();
    }

    public void radioClick(View view) {
        if(view.getId() == R.id.profesor)
            kopce = "profesor";
        else
            kopce = "student";
    }
}