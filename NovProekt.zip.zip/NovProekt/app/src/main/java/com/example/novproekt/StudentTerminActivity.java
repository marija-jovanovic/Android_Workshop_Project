package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class StudentTerminActivity extends AppCompatActivity {

    String korisnik;

    String selektiran;

    RecyclerView mRecyclerView;
    studentAdapter sAdapter;
    private SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_termin);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");


        db = openOrCreateDatabase("workshop", MODE_PRIVATE, null);

        List<String> predmeti = new ArrayList<String>();

        Cursor c = db.rawQuery("SELECT * FROM zapisan WHERE STUDENT_ID = '" + korisnik + "'", null); //da si odbere svoj predmet studentot
        if (c != null) {
            if (c.moveToFirst()) {
                predmeti.add(c.getString(0));
            }
            while (c.moveToNext()) {
                predmeti.add(c.getString(0));
            }
            c.close();
        }

        mRecyclerView = (RecyclerView) findViewById(R.id.list);
// оваа карактеристика може да се користи ако се знае дека промените
// во содржината нема да ја сменат layout големината на RecyclerView
        mRecyclerView.setHasFixedSize(true);
// ќе користиме LinearLayoutManager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
// и default animator (без анимации)
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());


        Spinner spin = (Spinner) findViewById(R.id.coursesspinner);
        spin.setAdapter(
                new ArrayAdapter(
                        this,
                        android.R.layout.simple_list_item_1,
                        predmeti));

        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> spin, View v, int i, long id) {

                selektiran = spin.getSelectedItem().toString();
                if (!selektiran.equals("Choose your course")) {
                    List<String> moi_termini = new ArrayList<String>(); //site termini za odbraniot predmet
                    List<String> vreme = new ArrayList<String>();
                    Cursor c1 = db.rawQuery("SELECT * FROM termini WHERE PREDMET = '" + selektiran + "'", null);
                    if (c1 != null) {
                        if (c1.moveToFirst()) {
                            moi_termini.add(c1.getString(1));
                            moi_termini.add(c1.getString(2));
                            moi_termini.add(c1.getString(3));
                            moi_termini.add(c1.getString(4));
                            vreme.add(c1.getString(3));
                        }
                        while (c1.moveToNext()) {
                            moi_termini.add(c1.getString(1));
                            moi_termini.add(c1.getString(2));
                            moi_termini.add(c1.getString(3));
                            moi_termini.add(c1.getString(4));
                            vreme.add(c1.getString(3));

                        }
                        c1.close();
                    }

// сетирање на кориснички дефиниран адаптер myAdapter (посебна класа)
                    sAdapter = new studentAdapter(moi_termini, R.layout.my_row2, StudentTerminActivity.this);
//прикачување на адаптерот на RecyclerView
                    mRecyclerView.setAdapter(sAdapter);

                    // notifyThis(moi_termini, vreme);

                }
            }

            public void onNothingSelected(AdapterView<?> parent) {
            } // empty
        });


    }


    public void back(View view) {
        finish();
    }
}




