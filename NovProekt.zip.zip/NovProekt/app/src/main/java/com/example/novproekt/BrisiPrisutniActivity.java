package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class BrisiPrisutniActivity extends AppCompatActivity {

    private String korisnik;
    private String cas_id;
    private String datum;

    private SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_brisi_prisutni);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");
        cas_id = intent.getExtras().getString("casId");
        datum = intent.getExtras().getString("datum");

        db = openOrCreateDatabase("workshop",MODE_PRIVATE,null);

        TextView tv = (TextView) findViewById(R.id.pozdrav);
        tv.setText("Would you like to delete " + korisnik + " from the presence list for the class with class id: " + cas_id
        + " and date: " + datum + "?");


    }

    public void izbrisi(View view) {
        db.execSQL("delete from "+"prisutni"+" where STUDENT_ID='"+korisnik+"'" + "AND CAS_ID='"+cas_id+"'"
        + "AND DATUM='"+datum+"'");
        Toast.makeText(this, "Successfully removed " + korisnik + " from the presence list.", Toast.LENGTH_SHORT).show();
    }
}