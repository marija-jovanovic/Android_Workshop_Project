package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RegisterCourseActivity extends AppCompatActivity {

    private SQLiteDatabase db;

    private EditText course;

    private Button kopce;
    String korisnik;

    myAdapter mAdapter;

    RecyclerView mRecyclerView;

    String selektiran;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_course);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");

        db = openOrCreateDatabase("workshop",MODE_PRIVATE,null);
        //db.execSQL("DROP TABLE IF EXISTS register_course");

        String CREATE_TABLE_REGISTER_COURSE = "CREATE TABLE IF NOT EXISTS register_course" + " ("
                 + "PREDMET VARCHAR PRIMARY KEY," + "PROF_ID VARCHAR" + ")";
        db.execSQL(CREATE_TABLE_REGISTER_COURSE);

        List<String> predmeti = new ArrayList<String>();
        predmeti.add("Choose your course");
        predmeti.add("Android programiranje");
        predmeti.add("Forenzika na mrezi");
        predmeti.add("Sigurnosni komunikacii");
        predmeti.add("Matematika 1");
        predmeti.add("Matematika 2");
        predmeti.add("Elektrotehnika");
        predmeti.add("Energetika");
        predmeti.add("Programiranje i algoritmi");
        predmeti.add("Elektronika");
        predmeti.add("Paralelno programiranje");
        predmeti.add("Matematika 3");
        predmeti.add("Verojatnost");
        predmeti.add("Diskretna matematika");
        predmeti.add("Fizika 1");
        predmeti.add("Fizika 2");
        predmeti.add("Komunikaciski tehnologii");

        List<String> values = new ArrayList<String>(); //predmetite sto gi ima zapisano
        Cursor c = db.rawQuery("SELECT * FROM register_course WHERE PROF_ID = '" + korisnik + "'", null);
        if(c != null) {
            if(c.moveToFirst()){
                values.add(c.getString(0));
            }
            while (c.moveToNext()) {
                values.add(c.getString(0));
            }
            c.close();
        }

        List<String> tugji = new ArrayList<String>(); //predmetite sto drugite profesori gi imaat zapisano
        Cursor c2 = db.rawQuery("SELECT * FROM register_course WHERE PROF_ID != '" + korisnik + "'", null);
        if(c2 != null) {
            if(c2.moveToFirst()){
                tugji.add(c2.getString(0));
            }
            while (c2.moveToNext()) {
                tugji.add(c2.getString(0));
            }
            c2.close();
        }

        if(!values.isEmpty()){
            for(int i = 0; i < values.size(); i++){
                for(int j = 0; j < predmeti.size(); j++){
                    if(values.get(i).equals(predmeti.get(j)))
                        predmeti.remove(j);
                }
            }
        }

        if(!tugji.isEmpty()){
            for(int i = 0; i < tugji.size(); i++){
                for(int j = 0; j < predmeti.size(); j++){
                    if(tugji.get(i).equals(predmeti.get(j)))
                        predmeti.remove(j);
                }
            }
        }

        //сетирање на RecyclerView контејнерот
        mRecyclerView = (RecyclerView) findViewById(R.id.list);
// оваа карактеристика може да се користи ако се знае дека промените
// во содржината нема да ја сменат layout големината на RecyclerView
        mRecyclerView.setHasFixedSize(true);
// ќе користиме LinearLayoutManager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
// и default animator (без анимации)
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
// сетирање на кориснички дефиниран адаптер myAdapter (посебна класа)
        mAdapter = new myAdapter(values, R.layout.my_row, this);
//прикачување на адаптерот на RecyclerView
        mRecyclerView.setAdapter(mAdapter);



        Spinner spin = (Spinner) findViewById(R.id.coursesspinner);
        spin.setAdapter(
                new ArrayAdapter(
                        this,
                        android.R.layout.simple_list_item_1,
                        predmeti));

        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> spin, View v, int i, long id) {

                selektiran = spin.getSelectedItem().toString();
                if(!selektiran.equals("Choose your course")) {
                    ContentValues insertValues = new ContentValues();
                    insertValues.put("PREDMET", selektiran);
                    insertValues.put("PROF_ID", korisnik);
                    db.insert("register_course", null, insertValues);
                    Toast.makeText(RegisterCourseActivity.this, "Successfully registered.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }


            // TextView result = (TextView) findViewById(R.id.turtle_result);

            public void onNothingSelected(AdapterView<?> parent) {} // empty
        });


    }


    public void back(View view) {
        finish();
    }
}