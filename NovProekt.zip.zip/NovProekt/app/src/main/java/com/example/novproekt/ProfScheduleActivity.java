package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ProfScheduleActivity extends AppCompatActivity {

    String korisnik;
    private SQLiteDatabase db;

    RecyclerView mRecyclerView;
    profAdapter pAdapter;

    String selektiran;

    String izbran_predmet;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prof_schedule);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");
        db = openOrCreateDatabase("workshop",MODE_PRIVATE,null);

        //сетирање на RecyclerView контејнерот
        mRecyclerView = (RecyclerView) findViewById(R.id.list);
// оваа карактеристика може да се користи ако се знае дека промените
// во содржината нема да ја сменат layout големината на RecyclerView
        mRecyclerView.setHasFixedSize(true);
// ќе користиме LinearLayoutManager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
// и default animator (без анимации)
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());


        List<String> moi_predmeti = new ArrayList<String>(); //predmetite sto gi ima zapisano
        moi_predmeti.add("Choose your course");
        Cursor c = db.rawQuery("SELECT * FROM register_course WHERE PROF_ID = '" + korisnik + "'", null);
        if(c != null) {
            if(c.moveToFirst()){
                moi_predmeti.add(c.getString(0));
            }
            while (c.moveToNext()) {
                moi_predmeti.add(c.getString(0));
            }
            c.close();
        }

        Spinner spin = (Spinner) findViewById(R.id.coursesspinner);
        spin.setAdapter(
                new ArrayAdapter(
                        this,
                        android.R.layout.simple_list_item_1,
                        moi_predmeti));

        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> spin, View v, int i, long id) {

                selektiran = spin.getSelectedItem().toString();
                if(!selektiran.equals("Choose your course")) {
                    izbran_predmet = selektiran;
                    List<String> moi_termini = new ArrayList<String>(); //predmetite sto gi ima zapisano
                    Cursor c1 = db.rawQuery("SELECT * FROM termini WHERE PREDMET = '" + izbran_predmet + "'", null);
                    if(c1 != null) {
                        if(c1.moveToFirst()){
                            moi_termini.add(c1.getString(1));
                            moi_termini.add(c1.getString(2));
                            moi_termini.add(c1.getString(3));
                            moi_termini.add(c1.getString(4));
                        }
                        while (c1.moveToNext()) {
                            moi_termini.add(c1.getString(1));
                            moi_termini.add(c1.getString(2));
                            moi_termini.add(c1.getString(3));
                            moi_termini.add(c1.getString(4));
                        }
                        c1.close();
                    }
// сетирање на кориснички дефиниран адаптер myAdapter (посебна класа)
                    pAdapter = new profAdapter(moi_termini, R.layout.my_row1, ProfScheduleActivity.this);
//прикачување на адаптерот на RecyclerView
                    mRecyclerView.setAdapter(pAdapter);
                }
            }

            public void onNothingSelected(AdapterView<?> parent) {} // empty
        });

       //ili tuka bese se ova




    }

    public void back(View view) {
        finish();
    }
}