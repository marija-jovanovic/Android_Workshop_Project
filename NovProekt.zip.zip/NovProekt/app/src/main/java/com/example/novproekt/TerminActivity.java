package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class TerminActivity extends AppCompatActivity {
    String korisnik;

   // private Context context;
    String selektiran;
    String selektiran1;
    Button kopce;
    Button pocetok;
    Button kraj;
    int zname = 0;

    int unikat = 1;
    ContentValues insertValues;
    private TimePicker timePicker1;
    private TimePicker timePicker2;
    private Cursor kursor;

    List<String> pocetoci = new ArrayList<String>();
    List<String> kraevi = new ArrayList<String>();

    List<Boolean> flagovi1 = new ArrayList<Boolean>();

    List<Boolean> flagovi2 = new ArrayList<Boolean>();
   // public static final String NOTIFICATION_CHANNEL_ID = "10001" ;
    //private final static String default_notification_channel_id = "default" ;
    private SQLiteDatabase db;

    public static final String NOTIFICATION_CHANNEL_ID = "10001";
    private final static String default_notification_channel_id = "default";

    //final Calendar myCalendar = Calendar.getInstance();
    int b = 0;

  //  public static final int ID_NOTIFICATION_DL_COMPLETE = 1234;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_termin);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");


        insertValues = new ContentValues();
        kopce = (Button) findViewById(R.id.back_button);
        pocetok = (Button) findViewById(R.id.start_button);
        kraj = (Button) findViewById(R.id.end_button);
        timePicker1 = (TimePicker) findViewById(R.id.timePicker1);
        timePicker1.setIs24HourView(true);
        timePicker2 = (TimePicker) findViewById(R.id.timePicker2);
        timePicker2.setIs24HourView(true);

        db = openOrCreateDatabase("workshop",MODE_PRIVATE,null);
       // db.execSQL("DROP TABLE IF EXISTS termini");

        String CREATE_TABLE_TERMINI = "CREATE TABLE IF NOT EXISTS termini" + " ("
                + "CAS_ID INTEGER PRIMARY KEY," + "PREDMET VARCHAR," + "DEN VARCHAR," + "START_TIME VARCHAR," + "END_TIME VARCHAR"  + ")";
        db.execSQL(CREATE_TABLE_TERMINI);

        List<String> predmeti = new ArrayList<String>(); //predmetite sto gi drzi
        predmeti.add("Choose your course");
        Cursor c = db.rawQuery("SELECT * FROM register_course WHERE PROF_ID = '" + korisnik + "'", null);
        if(c != null) {
            if(c.moveToFirst()){
                predmeti.add(c.getString(0));
            }
            while (c.moveToNext()) {
                predmeti.add(c.getString(0));
            }
            c.close();
        }


        Spinner spin = (Spinner) findViewById(R.id.coursesspinner);
        spin.setAdapter(
                new ArrayAdapter(
                        this,
                        android.R.layout.simple_list_item_1,
                        predmeti));

        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> spin, View v, int i, long id) {

                selektiran = spin.getSelectedItem().toString();
                if(!selektiran.equals("Choose your course")) {
                    insertValues.put("PREDMET", selektiran);
                }
            }

            public void onNothingSelected(AdapterView<?> parent) {} // empty
        });

        List<String> denovi = new ArrayList<String>();
        denovi.add("Choose the day");
        denovi.add("Monday");
        denovi.add("Tuesday");
        denovi.add("Wednesday");
        denovi.add("Thursday");
        denovi.add("Friday");

        Spinner spin1 = (Spinner) findViewById(R.id.denspinner);
        spin1.setAdapter(
                new ArrayAdapter(
                        this,
                        android.R.layout.simple_list_item_1,
                        denovi));

        spin1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> spin1, View v, int i, long id) {

                selektiran1 = spin1.getSelectedItem().toString();
                if(!selektiran1.equals("Choose the day")) {
                    insertValues.put("DEN", selektiran1);
                }

            }

            public void onNothingSelected(AdapterView<?> parent) {} // empty
        });

    }
    public void back(View view) {

        if(insertValues.size() == 4) {

            String naslov = "";
           // String denovi = insertValues.getAsString("DEN");
            //String casovi = insertValues.getAsString("START_TIME");
            String denovi="";
            String casovi="";
                db.insert("termini", null, insertValues);
                Toast.makeText(TerminActivity.this, "The appointment was successfully made.", Toast.LENGTH_SHORT).show();

            Cursor c = db.rawQuery("SELECT * FROM termini", null);
           // int unikat = 1;
            if(c != null) {
                if(c.moveToLast()) {
                    unikat = Integer.parseInt(c.getString(0)); //zemi go id-to na terminot
                    naslov = c.getString(1);
                    denovi = c.getString(2);
                    casovi = c.getString(3);
                }
            }
            c.close();

          //  if(unikat > 1)
            //    unikat++;



            int day = 0;
            int d = 0;
            int ca = 0;

                if (denovi.equals("Monday"))
                    day = 2;
                if (denovi.equals("Tuesday"))
                    day = 3;
                if (denovi.equals("Wednesday"))
                    day = 4;
                if (denovi.equals("Thursday"))
                    day = 5;
                if (denovi.equals("Friday"))
                    day = 6;

                String[] niz = casovi.split(":");
                //niz[0] go sodrzi casot, a niz[1] gi sodrzi minutite



          /*  Notification.Builder builder = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                builder = new Notification.Builder(this,
                        "com.example.novproekt");
            }
            else {
                builder = new Notification.Builder(this);
            }

           // Notification.Builder builder = new Notification.Builder(this);
            builder.setContentTitle(naslov);
            builder.setContentText("Lesson begins in 2 hours!");
            builder.setSmallIcon(R.drawable.baseline_notifications_24);
            //builder.build();
*/

            createNotificationChannel();

            Calendar calendar = Calendar.getInstance();
           // calendar.setTimeInMillis(System.currentTimeMillis());
            calendar.setTimeZone(TimeZone.getTimeZone("CET"));
            calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(niz[0]) - 2); //2hours before
            calendar.set(Calendar.MINUTE, Integer.parseInt(niz[1]));
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);

            Log.d("notifikacija", String.valueOf(calendar.get(Calendar.HOUR_OF_DAY)));
            Log.d("notifikacija", String.valueOf(calendar.get(Calendar.MINUTE)));
            Log.d("notifikacija", naslov);
            Log.d("notifikacija", String.valueOf(unikat));

           // Intent intent1 = new Intent(TerminActivity.this, MyNotificationPublisher.class);
            //intent1.putExtra(MyNotificationPublisher.NOTIFICATION_ID, unikat);
            //intent1.putExtra(MyNotificationPublisher.NOTIFICATION, builder.build());
            //PendingIntent pendingIntent = PendingIntent.getBroadcast(TerminActivity.this, unikat, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
            //AlarmManager alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
            //alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY * 7, pendingIntent);

           AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
           //calendar.setTimeInMillis(System.currentTimeMillis());
            Intent intent = new Intent(TerminActivity.this, MyNotificationPublisher.class);
            intent.putExtra(MyNotificationPublisher.NOTIFICATION_ID, unikat);
            intent.putExtra("Naslov", naslov);
           PendingIntent pendingIntent = PendingIntent.getBroadcast(TerminActivity.this, unikat, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY*7, pendingIntent);
            Toast.makeText(TerminActivity.this, "Alarm Set", Toast.LENGTH_SHORT).show();
        }

        finish();
    }

    public void pocetokk(View view) {
        timePicker1 = (TimePicker) findViewById(R.id.timePicker1);
        int start_hour = timePicker1.getHour();
        int start_min = timePicker1.getMinute();
        String start_time = String.valueOf(start_hour) + ":" + String.valueOf(start_min);
        insertValues.put("START_TIME", start_time);
        Toast.makeText(TerminActivity.this, "Successfully inserted starting time.", Toast.LENGTH_SHORT).show();

    }

    public void krajj(View view) {
        timePicker2 = (TimePicker) findViewById(R.id.timePicker2);
        int end_hour = timePicker2.getHour();
        int end_min = timePicker2.getMinute();
        String end_time = String.valueOf(end_hour) + ":" + String.valueOf(end_min);
        insertValues.put("END_TIME", end_time);
        Toast.makeText(TerminActivity.this, "Successfully inserted ending time.", Toast.LENGTH_SHORT).show();

    }

    private void createNotificationChannel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name = "akchannel";
            String desc = "Channel for Alarm Manager";
            int imp = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel channel = new NotificationChannel("androidknowledge", name, imp);
            channel.setDescription(desc);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }




}