package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.media.Rating;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;


public class AnketaActivity extends AppCompatActivity {

    private String cas_id;
    private String datum;

    private String komentar;

    private SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anketa);

        Intent intent = getIntent();
        cas_id = intent.getExtras().getString("cas_id");
        datum = intent.getExtras().getString("datum");

        db = openOrCreateDatabase("workshop",MODE_PRIVATE,null);
        String CREATE_TABLE_ANKETA = "CREATE TABLE IF NOT EXISTS anketa" + " ("
                +"CAS_ID VARCHAR PRIMARY KEY," + "OCENA VARCHAR," + "KOMENTAR VARCHAR," + "DATUM VARCHAR" + ")";
        db.execSQL(CREATE_TABLE_ANKETA);

    }

    public void naPotvrda(View view) {
        EditText et = (EditText) findViewById(R.id.komentar);
        RatingBar rb = (RatingBar) findViewById(R.id.ocena);
        String rating=String.valueOf(rb.getRating());
        komentar = et.getText().toString();
        ContentValues insertValues = new ContentValues();
        insertValues.put("CAS_ID", cas_id);
        insertValues.put("OCENA", rating);
        insertValues.put("KOMENTAR", komentar);
        insertValues.put("DATUM", datum);
        db.insert("anketa", null, insertValues);
        Toast.makeText(this, "Successfully sent.", Toast.LENGTH_SHORT).show();

        //Intent i = new Intent(AnketaActivity.this, StudentActivity.class);
        //startActivity(i);
        finish();
    }
}