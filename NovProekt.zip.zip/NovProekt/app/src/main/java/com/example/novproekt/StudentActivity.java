package com.example.novproekt;



import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class StudentActivity extends AppCompatActivity {

    private String korisnik;

    Button enrol;

    private SQLiteDatabase db;

   // public static final int ID_NOTIFICATION_DL_COMPLETE = 1234;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");

        TextView tekst;
        tekst = (TextView) findViewById(R.id.pozdrav);
        tekst.setText("Hello, " + korisnik);

       db = openOrCreateDatabase("workshop", MODE_PRIVATE, null);
        String CREATE_TABLE_STUDENT = "CREATE TABLE IF NOT EXISTS student" + " ("
                + "ID VARCHAR PRIMARY KEY " + ")";
        db.execSQL(CREATE_TABLE_STUDENT);

        ContentValues insertValues = new ContentValues();
        insertValues.put("ID", korisnik);
        db.insert("student", null, insertValues);

    }


    public void enroll(View view) {
        enrol = (Button) findViewById(R.id.enroll_course);
        Intent i = new Intent(StudentActivity.this, EnrollCourseActivity.class);
        i.putExtra("id", korisnik);
        startActivity(i);
    }

    @Override
    protected void onPause() {
        super.onPause();
        db.close();
    }

    public void kalendar(View view) {
        Intent i = new Intent(StudentActivity.this, StudentTerminActivity.class);
        i.putExtra("id", korisnik);
        startActivity(i);
    }

    public void tekovniCasovi(View view) {
        Intent i = new Intent(StudentActivity.this, StudentCurrentTerminActivity.class);
        i.putExtra("id", korisnik);
        startActivity(i);
    }
}