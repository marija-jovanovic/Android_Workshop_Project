package com.example.novproekt;

public class ProfesorInfo {

    // string variable for
    // storing employee name.

    // string variable for storing
    // employee address.
    private String professorAddress;
    private String role;

    // an empty constructor is
    // required when using
    // Firebase Realtime Database.
    public ProfesorInfo() {

    }

    // created getter and setter methods
    // for all our variables.
    public String getProfesorAddress() {
        return professorAddress;
    }

    public void setprofessorAddress(String professorAddress) {
        this.professorAddress = professorAddress;
    }

    public String getRole(){
        return role;
    }

    public void setRole(String role){
        this.role = role;
    }
}
