package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Toast;

import java.util.Calendar;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class StudentCurrentTerminActivity extends AppCompatActivity {

    public String korisnik;

    private SQLiteDatabase db;

    RecyclerView mRecyclerView;
    tAdapter tAdapter;

    private String den;

    int flag = 0;

    int negov = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_current_termin);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");


        db = openOrCreateDatabase("workshop", MODE_PRIVATE, null);


        List<String> predmeti = new ArrayList<String>();
        List<String> tekovni_termini = new ArrayList<String>();

        //DayOfWeek dayOfWeek = LocalDate.now().getDayOfWeek();
        Calendar now = Calendar.getInstance();
        int dayOfWeek = now.get(Calendar.DAY_OF_WEEK);
        if (dayOfWeek == 2)
            den = "Monday";
        if (dayOfWeek == 3)
            den = "Tuesday";
        if (dayOfWeek == 4)
            den = "Wednesday";
        if (dayOfWeek == 5)
            den = "Thursday";
        if (dayOfWeek == 6)
            den = "Friday";
       // now.set(Calendar.DAY_OF_WEEK, 2);
       // now.set(Calendar.HOUR_OF_DAY, 13);
        //now.set(Calendar.MINUTE, 15);
        //den = "Monday";
        //else {
          //  Toast.makeText(this, "Weekend", Toast.LENGTH_SHORT).show();
            //finish();
        //}


        Cursor c = db.rawQuery("SELECT * FROM zapisan WHERE STUDENT_ID = '" + korisnik + "'", null); //najdi gi site predmeti sto gi slusa najaveniot student
        if (c != null) {
            if (c.moveToFirst()) {
                predmeti.add(c.getString(0));
            }
            while (c.moveToNext()) {
                predmeti.add(c.getString(0));
            }
            c.close();
        }


        flag = 0;
        negov = 0;
        Cursor cu = db.rawQuery("SELECT * FROM termini WHERE DEN = '" + den + "'", null);
        // cu.moveToFirst();
        if (cu.moveToFirst()){

            do {


                String pocetno[] = cu.getString(3).split(":");
                String krajno[] = cu.getString(4).split(":");
                if ((now.get(Calendar.HOUR_OF_DAY) >= Integer.parseInt(pocetno[0])) &&
                        (now.get(Calendar.HOUR_OF_DAY) <= Integer.parseInt(krajno[0]))) {
                    if (now.get(Calendar.HOUR_OF_DAY) == Integer.parseInt(pocetno[0])) {
                        if (now.get(Calendar.MINUTE) < Integer.parseInt(pocetno[1])) {
                            // cu.close();
                            //continue;
                            flag = 1;
                        }
                    }
                    if (now.get(Calendar.HOUR_OF_DAY) == Integer.parseInt(krajno[0])) {
                        if (now.get(Calendar.MINUTE) > Integer.parseInt(krajno[1])) {
                            // cu.close();
                            //continue;
                            flag = 1;
                        }
                    }

                    if (flag == 0) {
                        for (int i = 0; i < predmeti.size(); i++) {
                            if (cu.getString(1).equals(predmeti.get(i))) {
                                negov = 1;
                                break;
                            }
                        }
                        //tuka e logikata ako se e vo red so uslovite odnosno ako e tekoven termin
                        if (negov == 1)
                            tekovni_termini.add(cu.getString(0) + "\n" + cu.getString(1) +
                                    "\n" + cu.getString(2) + "\n" + cu.getString(3) + "\n" +
                                    cu.getString(4) + "\n" + korisnik);
                    }


                    flag = 0;
                    negov = 0;

                }
                flag = 0;
                negov = 0;

            } while (cu.moveToNext());
        cu.close();
    }

                   /* tekovni_termini.add(cu.getString(0));
                    tekovni_termini.add(cu.getString(1));
                    tekovni_termini.add(cu.getString(2));
                    tekovni_termini.add(cu.getString(3));
                    tekovni_termini.add(cu.getString(4)); */







        //сетирање на RecyclerView контејнерот
     mRecyclerView = (RecyclerView) findViewById(R.id.list);
// оваа карактеристика може да се користи ако се знае дека промените
// во содржината нема да ја сменат layout големината на RecyclerView
       mRecyclerView.setHasFixedSize(true);
// ќе користиме LinearLayoutManager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
// и default animator (без анимации)
       mRecyclerView.setItemAnimator(new DefaultItemAnimator());
// сетирање на кориснички дефиниран адаптер myAdapter (посебна класа)
        tAdapter = new tAdapter(tekovni_termini, R.layout.my_rowt, this);
//прикачување на адаптерот на RecyclerView
        mRecyclerView.setAdapter(tAdapter);



    }
}