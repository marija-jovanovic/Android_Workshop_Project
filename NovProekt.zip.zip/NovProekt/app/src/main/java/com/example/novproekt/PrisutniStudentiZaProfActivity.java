package com.example.novproekt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class PrisutniStudentiZaProfActivity extends AppCompatActivity {

    private String korisnik;
    private String cas_id;
    private String datum;

    private SQLiteDatabase db;

    RecyclerView mRecyclerView;
    prisutniAdapter pAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prisutni_studenti_za_prof);

        Intent intent = getIntent();
        korisnik = intent.getExtras().getString("id");
        cas_id = intent.getExtras().getString("casId");
        datum = intent.getExtras().getString("datum");

        Date date = Calendar.getInstance().getTime();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
       String today = formatter.format(date);

        db = openOrCreateDatabase("workshop",MODE_PRIVATE,null);
        List<String> studenti = new ArrayList<String>();
        Cursor cursor = db.rawQuery("SELECT * FROM prisutni", null);
        cursor.moveToFirst();
        do {
            if(cursor.getString(1).equals(cas_id) && cursor.getString(2).equals(today)){
                studenti.add(cursor.getString(0) + "\n" + cursor.getString(1)
                + "\n" + cursor.getString(2));
            }

        } while (cursor.moveToNext());
        cursor.close();

        //сетирање на RecyclerView контејнерот
        mRecyclerView = (RecyclerView) findViewById(R.id.list);
// оваа карактеристика може да се користи ако се знае дека промените
// во содржината нема да ја сменат layout големината на RecyclerView
        mRecyclerView.setHasFixedSize(true);
// ќе користиме LinearLayoutManager
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
// и default animator (без анимации)
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
// сетирање на кориснички дефиниран адаптер myAdapter (посебна класа)
        pAdapter = new prisutniAdapter(studenti, R.layout.moj_red, this);
//прикачување на адаптерот на RecyclerView
        mRecyclerView.setAdapter(pAdapter);


    }
}